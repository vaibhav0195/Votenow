# check gender by the name of child
import nltk
import random
from nltk.corpus import names

labeled_names = ([(name, 'male') for name in names.words('male.txt')] +[(name, 'female') for name in names.words('female.txt')])
random.shuffle(labeled_names)

def gender_features(word):
	return {'last_letter': word[-1],'length':len(word)}


def get_gender(name):
	featuresets = [(gender_features(n), gender) for (n, gender) in labeled_names]
	train_set, test_set = featuresets[500:], featuresets[:500]
	classifier = nltk.NaiveBayesClassifier.train(train_set)
	return classifier.classify(gender_features(name))

def main():
	print '********************'

	print 'ENTER THE NAME OF PERSON :-'
	name = raw_input()
	gender = get_gender(name)
	print 'GENDER OF THE PERSON IS :-\t', gender

	print '********************'

if __name__ == '__main__':
	main()